import java.util.ArrayList;
import java.util.List;

/**
 *	ExpressionTree - Creates an expression tree from an expression given
 *				in infix notation.
 *
 *	@author	
 *	@since	
 */
public class ExpressionTree {
		
	private List<String> tokens;		// the tokens of the expression
	private int tokenIndex;				// index into tokens
	
	private String expr;				// expression
	
	private TreeNode<String> root;		// the root node of the expression tree
	
	private ExprUtils utils;			// utilities to tokenize expression
	
	private final int PRINT_SPACES = 3;	// number of spaces between tree levels
										// used by printTree()
	
	// constructor
	public ExpressionTree() {}
	
	public static void main(String[] args) {
		ExpressionTree et = new ExpressionTree();
		et.run();
	}
	
	public void run() {
		System.out.println("\nWelcome to ExpressionTree!!!");
		treeMakerInterface();
		System.out.println("\nThanks for using ExpressionTree! Goodbye.\n");
	}
	
	/**
	 *	The user interface for the Expression Tree
	 */
	public void treeMakerInterface() {	}
	
	/**	Print help */
	public void printMenu() {
		System.out.println("\nCurrent expression: " + expr);
		System.out.println("\nChoose:");
		System.out.println("  (i) input new expression");
		System.out.println("  (pre) print prefix notation");
		System.out.println("  (in) print infix notation");
		System.out.println("  (post) print postfix notation");
		System.out.println("  (e) evaluate expression");
		System.out.println("  (p) print tree");
		System.out.println("  (q) quit");
	}
	
	/**	Builds a Binary Expression Tree from tokens.
	 *	@return		root of expression tree
	 *
	 *	Algorithm: (describe here)
	 */
	public TreeNode<String> buildTree() {
	 	// create TreeNode stack
	 	ArrayStack<TreeNode<String>> treeStack = new ArrayStack<TreeNode<String>>();
	 	
		return null;
	}

	/**
	 *	Evaluate the expression in the ExpressionTree
	 *	@return		the evaluated answer
	 */
	public double evaluateExpression() {
		
		return 0.0;
	}
	
	/**
	 *	Print expression tree
	 *	@param root		root node of binary tree
	 *
	 *	Prints in vertical order, top of output is right-side of tree,
	 *			bottom is left side of tree,
	 *			left side of output is root, right side is deepest leaf
	 *	Example tree (expression "5 + 2 * 3""):
	 *			  +
	 *			/	\
	 *		  /		  \
	 *		5			*
	 *				  /	  \
	 *				2		3
	 *
	 *	would be output as:
	 *
	 *				3
	 *			*
	 *				2
	 *		+
	 *			5
	 */
	public void printTree() {
		printLevel(root, 0);
	}
	
	/**
	 *	Recursive node printing method
	 *	Prints reverse order: right subtree, node, left subtree
	 *	Prints the node spaced to the right by level number
	 *	@param node		root of subtree
	 *	@param level	level down from root (root level = 0)
	 */
	public void printLevel(TreeNode<String> node, int level) {
		if (node == null) return;
		// print right subtree
		printLevel(node.getRight(), level + 1);
		// print node: print spaces for level, then print value in node
		for (int a = 0; a < PRINT_SPACES * level; a++) System.out.print(" ");
		System.out.println(node.getValue());
		// print left subtree
		printLevel(node.getLeft(), level + 1);
	}
	
}