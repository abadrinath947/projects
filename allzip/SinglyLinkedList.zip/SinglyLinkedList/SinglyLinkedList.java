/**
 *	Sets up a singly linked list of ListNode's.
 *	
 *	@author	
 *	@since	
 */
public class SinglyLinkedList<E extends Comparable<E>>
{
	private ListNode<E> head;		// the first ListNode in the list

	/**
	 *	Constructor creates a list with no nodes
	 */
	public SinglyLinkedList()
	{
	}
	
	/* Copy constructor */
	public SinglyLinkedList(SinglyLinkedList<E> list)
	{
		
	}
	
	/**
	 *	Add an Object to the head of the list
	 *	@param value  the Object to add
	 */
	public void addFirst(E value) 
	{
		
	}
	
	/**
	 *	Get the first ListNode of the list
	 *	@return  the first ListNode in the list
	 */
	public ListNode<E> getFirst()
	{
		return null;
	}
	
	/**
	 *	Print out the singly linked list
	 */
	public void printList()
	{
		ListNode<E> ptr = head; // start at the first node
		while (ptr != null) 
		{
			System.out.print(ptr.getValue() + " ");
			ptr = ptr.getNext(); // go to next node
		}
	}
}
