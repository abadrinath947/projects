import java.util.ArrayList;
import info.gridworld.grid.Location;
import info.gridworld.actor.Actor;
import info.gridworld.actor.Critter;
import info.gridworld.actor.Rock;
public class Coyote extends Critter
{
	private int steps, sleep;

	public Coyote()
	{
		setColor(null);
		steps = sleep = 0;

		int dir = (int)(Math.random()*8);
		setDirection(dir*45);
	}

	public void processActors(ArrayList<Actor> actors)
    {
		boolean act = false;
		if (getGrid().isValid(getLocation().getAdjacentLocation(getDirection())))
			act = getGrid().get(getLocation().getAdjacentLocation(getDirection())) instanceof Actor;
		if (sleep == 0 && (steps > 4 || act || isEdgeOfGrid())) {
			sleep++;
			steps = 0;
		}
		
	  	else if (sleep == 4 && isEdgeOfGrid()) {
	  		sleep = 0;

	  		setDirection((int)(Math.random()*8) * 45);
	  			
	  	}
	  	else if (sleep == 4 && !isEdgeOfGrid()) {
	  		ArrayList<Location> a = getGrid().getEmptyAdjacentLocations(getLocation());
	  		if (a.size() != 0)
	  			(new Stone()).putSelfInGrid(getGrid(), a.get((int)(Math.random()*a.size())));
	  		sleep = 0;

	  		setDirection((int)(Math.random()*8) * 45);
	  			
	  	}
	  	else if (sleep != 0) {
	  		sleep++;
	  		
	  	}
    }
	
	  public Location selectMoveLocation(ArrayList<Location> locs)
	  {
		  	
		  	if (sleep == 0)
		  		return getLocation().getAdjacentLocation(getDirection());
		  	else
		  		return getLocation();
		  	
	  }
	  
	  public void makeMove(Location loc)
	  {
		  System.out.println("sleep: " + sleep + "Steps: " + steps);
		 if (getGrid().isValid(loc) && getGrid().get(loc) instanceof Boulder) {
			 getGrid().get(loc).removeSelfFromGrid();
			 
			 (new Kaboom()).putSelfInGrid(getGrid(), loc);
			 removeSelfFromGrid();
			 return;
		 }
		 else if (getGrid().isValid(loc) && getGrid().get(loc) == null) {
			 if (!loc.equals(getLocation())) steps++;
			 moveTo(loc);
			 
				 
		 }
			 
	  }
	  
	  private boolean isEdgeOfGrid() {
		  if (!getGrid().isValid(getLocation().getAdjacentLocation(getDirection())))
			  return true;
		  return false;
	  }
	  
	 
	
}
